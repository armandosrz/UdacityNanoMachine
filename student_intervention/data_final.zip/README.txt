Contents of Archive:
dataset.csv - This is a data set that you can use to test your neual network.  This IS NOT a full training set or a full test set.  It is meant to serve as an example for you to build upon.

neuro_example - This directory contains example source code (example.py) that demonstrates the use of the neuro package.  Be sure to place the neuro.py and linear_algebra.py files in the same directory as your project source code.  Otherwise, you program will not function!!!
